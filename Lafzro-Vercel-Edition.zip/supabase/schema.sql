-- LAFZRO V2 / Supabase schema. Run once in Supabase SQL Editor.
create extension if not exists pgcrypto;
create table if not exists public.profiles(id uuid primary key references auth.users(id) on delete cascade, display_name text not null default 'Member', email_hint text, avatar_url text, created_at timestamptz default now());
create table if not exists public.servers(id uuid primary key default gen_random_uuid(), name text not null check(char_length(name) between 1 and 80), owner_id uuid not null references auth.users(id), invite_code text unique not null default substr(encode(gen_random_bytes(8),'hex'),1,10), created_at timestamptz default now());
create table if not exists public.server_members(server_id uuid references public.servers(id) on delete cascade,user_id uuid references auth.users(id) on delete cascade,role text not null default 'member' check(role in('owner','admin','moderator','member')),joined_at timestamptz default now(),primary key(server_id,user_id));
create table if not exists public.channels(id uuid primary key default gen_random_uuid(),server_id uuid not null references public.servers(id) on delete cascade,name text not null check(char_length(name) between 1 and 60),position int not null default 0,created_at timestamptz default now());
create table if not exists public.messages(id uuid primary key default gen_random_uuid(),channel_id uuid not null references public.channels(id) on delete cascade,author_id uuid not null references auth.users(id) on delete cascade,content text not null check(char_length(content) between 1 and 4000),created_at timestamptz default now(),edited_at timestamptz);
create index if not exists messages_channel_created on public.messages(channel_id,created_at);
alter table public.profiles enable row level security;alter table public.servers enable row level security;alter table public.server_members enable row level security;alter table public.channels enable row level security;alter table public.messages enable row level security;
create or replace function public.is_member(s uuid) returns boolean language sql stable security definer set search_path=public as $$select exists(select 1 from server_members where server_id=s and user_id=auth.uid())$$;
create or replace function public.is_staff(s uuid) returns boolean language sql stable security definer set search_path=public as $$select exists(select 1 from server_members where server_id=s and user_id=auth.uid() and role in('owner','admin'))$$;
create policy "profiles readable auth" on public.profiles for select to authenticated using(true);
create policy "profile update self" on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
create policy "servers member read" on public.servers for select to authenticated using(public.is_member(id));
create policy "members member read" on public.server_members for select to authenticated using(public.is_member(server_id));
create policy "channels member read" on public.channels for select to authenticated using(public.is_member(server_id));
create policy "channels staff insert" on public.channels for insert to authenticated with check(public.is_staff(server_id));
create policy "channels staff update" on public.channels for update to authenticated using(public.is_staff(server_id));
create policy "channels staff delete" on public.channels for delete to authenticated using(public.is_staff(server_id));
create policy "messages member read" on public.messages for select to authenticated using(exists(select 1 from channels c where c.id=channel_id and public.is_member(c.server_id)));
create policy "messages member send" on public.messages for insert to authenticated with check(author_id=auth.uid() and exists(select 1 from channels c where c.id=channel_id and public.is_member(c.server_id)));
create policy "messages own update" on public.messages for update to authenticated using(author_id=auth.uid()) with check(author_id=auth.uid());
create policy "messages own delete" on public.messages for delete to authenticated using(author_id=auth.uid());
create or replace function public.create_server(server_name text) returns uuid language plpgsql security definer set search_path=public as $$declare sid uuid;begin if auth.uid() is null then raise exception 'Not authenticated';end if;if length(trim(server_name))<1 or length(server_name)>80 then raise exception 'Invalid name';end if;insert into servers(name,owner_id) values(trim(server_name),auth.uid()) returning id into sid;insert into server_members(server_id,user_id,role) values(sid,auth.uid(),'owner');insert into channels(server_id,name,position) values(sid,'general',0);return sid;end$$;
grant execute on function public.create_server(text) to authenticated;
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$begin insert into profiles(id,display_name,email_hint,avatar_url) values(new.id,coalesce(new.raw_user_meta_data->>'full_name',split_part(new.email,'@',1),'Member'),split_part(new.email,'@',1),new.raw_user_meta_data->>'avatar_url') on conflict do nothing;return new;end$$;
drop trigger if exists on_auth_user_created on auth.users;create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
-- Enable the messages table in Database > Publications > supabase_realtime if realtime isn't automatically enabled.

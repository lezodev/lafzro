'use client'
import {useEffect,useState} from 'react';import {supabase} from '../../lib/supabase';import ChatApp from '../../components/ChatApp'
export default function Chat(){const [user,setUser]=useState(undefined);useEffect(()=>{supabase().auth.getUser().then(({data})=>{if(!data.user)location.href='/login';else setUser(data.user)})},[]);return user?<ChatApp user={user}/>:<div className="center">Loading Lafzro…</div>}

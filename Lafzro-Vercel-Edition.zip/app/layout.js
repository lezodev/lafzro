import './globals.css'
export const metadata={title:'Lafzro',description:'Communities, channels and conversations.'}
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}

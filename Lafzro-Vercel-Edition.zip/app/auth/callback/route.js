import { NextResponse } from 'next/server'
import { createServerClient } from '@supabase/ssr'
export async function GET(req){
 const url=new URL(req.url), code=url.searchParams.get('code'); const res=NextResponse.redirect(new URL('/chat',url.origin));
 if(code){const s=createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,{cookies:{getAll:()=>req.cookies.getAll(),setAll:(xs)=>xs.forEach(({name,value,options})=>res.cookies.set(name,value,options))}}); await s.auth.exchangeCodeForSession(code)}
 return res
}

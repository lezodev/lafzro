# Lafzro — Vercel Edition

A clean Discord-inspired community chat MVP built for Vercel. Stack: Next.js 15, React 19, Supabase Auth/Postgres/Realtime, RLS.

## Included
- Passwordless email OTP (6-digit when Supabase email template uses `{{ .Token }}`)
- Google OAuth
- Secure Supabase session cookies
- Community/server creation
- Text channels
- Realtime messages
- Edit/delete own messages
- Member list + owner/admin/member foundation
- Server-side database authorization through PostgreSQL RLS
- Message search (current loaded channel)
- Responsive, flat dark UI with no gradients/glass/neon

## 1. Create Supabase project
Create a project at Supabase. Open SQL Editor, paste `supabase/schema.sql`, and Run.

In Authentication > Providers, enable Email and Google. For Email OTP, edit the Magic Link email template to include `{{ .Token }}` so users receive a 6-digit OTP rather than only a link. Configure Google Client ID/Secret per Supabase's Google provider guide.

Add redirect URLs:
- local: `http://localhost:3000/auth/callback`
- production: `https://YOUR-VERCEL-DOMAIN/auth/callback`

Copy Project URL + anon/publishable key from Supabase project settings.

## 2. Local run
Copy `.env.example` to `.env.local` and fill both values.

```bash
npm install
npm run dev
```
Open http://localhost:3000.

## 3. GitHub + Vercel
Create a GitHub repo and upload this project. In Vercel: Add New > Project > Import the repo. Add both environment variables from `.env.example`, then Deploy.

After deployment, copy your `*.vercel.app` URL into Supabase Authentication URL configuration and Google OAuth authorized redirect setup as instructed by Supabase.

## Important production notes
This is a functional V2 foundation/MVP, not a literal clone of every Discord feature. Before a large public launch add: abuse reporting/moderation, rate limiting/CAPTCHA for OTP and message spam, Terms/Privacy, account deletion/export, backups, observability, content/file scanning, block system, stronger role permission matrix, invite/join UI, DM tables/UI, attachments with Storage policies, reactions, push notifications, and moderation audit logs.

Do not put Supabase service-role keys in browser code or `NEXT_PUBLIC_*`. RLS is intentionally enabled so clients cannot simply bypass membership rules by changing frontend code.
